# Source-Available License (Custom)

## Copyright © [2025] [ZlothY29IQ] [HanSolo1000Falcon] [KyleTheScientist]
### All rights reserved.

Permission is hereby granted to any individual or organization obtaining a copy of this repository (the “Software”) to view, download, and modify the Software for personal or internal use only, subject to the following conditions:


* No Redistribution - You may not publish, distribute, sublicense, or otherwise make the Software, or any derivative works thereof, publicly available in any form without prior written permission from the copyright holder.


* No Public Forks - You may not create or maintain public forks, mirrors, or copies of the Software on GitHub or any other platform.


* No Commercial Use - The Software may not be used, in whole or in part, for commercial purposes without explicit written permission from the copyright holder.


* Attribution - Any private use or modification of the Software must retain all copyright notices, disclaimers, and this license file.


* Termination - Any violation of the above conditions will automatically terminate your rights under this license.



* Disclaimer

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THE SOFTWARE.
